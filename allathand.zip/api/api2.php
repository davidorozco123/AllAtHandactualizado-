<?php

  var_dump(file_get_contents('php://input'));die;
